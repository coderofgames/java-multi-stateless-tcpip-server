/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Common;

/**
 *
 * @author CHUWI
 */
public class CourierSharedData {
    public static final int COURIER_PORT = 3412;

    public enum VehicleType {
        BICYCLE, MOTORBIKE, CAR, VAN, TRUCK
    };    
}
